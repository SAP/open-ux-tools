## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Wed Feb 11 2026 10:23:21 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator:@sapux/s4-fiori-gen-ext|
|**App Generator Version**<br>1.20.2|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>SAP System (ABAP On-Premise)|
|**Service URL**<br>http://er1clnt001:443/sap/opu/odata4/dmo/sb_travel_mdsk_o4/srvd/dmo/sd_travel_mdsk/0001/|
|**Module Name**<br>test.sample.mdsk.v4|
|**Application Title**<br>MDSK SAMPLE|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.144.1|
|**Enable TypeScript**<br>True|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/eslint-plugin-fiori-custom for the eslint rules.|
|**Main Entity**<br>Travel|
|**Navigation Entity**<br>_Booking|

## test.sample.mdsk.v4

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


