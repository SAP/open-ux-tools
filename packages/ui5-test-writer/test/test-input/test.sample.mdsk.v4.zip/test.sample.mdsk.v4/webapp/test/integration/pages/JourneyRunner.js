sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"test/sample/mdsk/v4/test/integration/pages/TravelList.gen",
	"test/sample/mdsk/v4/test/integration/pages/TravelObjectPage.gen",
	"test/sample/mdsk/v4/test/integration/pages/BookingObjectPage.gen"
], function (JourneyRunner, TravelListGenerated, TravelObjectPageGenerated, BookingObjectPageGenerated) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('test/sample/mdsk/v4') + '/index.html',
        pages: {
			onTheTravelListGenerated: TravelListGenerated,
			onTheTravelObjectPageGenerated: TravelObjectPageGenerated,
			onTheBookingObjectPageGenerated: BookingObjectPageGenerated
        },
        async: true
    });

    return runner;
});

