import type { AbapServiceProvider, ExternalService } from '@sap-ux/axios-extension';
import type { CheckBoxQuestion } from '@sap-ux/inquirer-common';
/**
 * Gets the value help selection prompt.
 *
 * @param servicePath - The service path
 * @param metadata - The service metadata
 * @param abapServiceProvider - The ABAP service provider
 * @returns Object containing questions and value help data reference
 */
export declare function getValueHelpSelectionPrompt(servicePath: string, metadata: string, abapServiceProvider: AbapServiceProvider): {
    questions: CheckBoxQuestion[];
    valueHelpData?: ExternalService[];
};
//# sourceMappingURL=value-help-prompts.d.ts.map