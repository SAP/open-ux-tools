sap.ui.define(['sap/ui/core/mvc/Controller', 'sap/ui/core/routing/History'], function (Controller, History) {
    'use strict';

    return Controller.extend('fin.central.listreport.controller.BaseController', {
        /**
         * Convenience method for accessing the event bus.
         * @public
         * @returns {sap.ui.core.EventBus} the event bus for this component
         */
        getEventBus: function () {
            return this.getOwnerComponent().getEventBus();
        },

        /**
         * Convenience method for accessing the router.
         * @public
         * @returns {sap.ui.core.routing.Router} the router for this component
         */
        getRouter: function () {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },

        /**
         * Convenience method for getting the view model by name.
         * @public
         * @param {string} [sName] the model name
         * @returns {sap.ui.model.Model} the model instance
         */
        getModel: function (sName) {
            return this.getView().getModel(sName);
        },

        /**
         * Convenience method for setting the view model.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel: function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Getter for the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getResourceBundle: function () {
            return this.getOwnerComponent().getModel('i18n').getResourceBundle();
        }
    });
});
