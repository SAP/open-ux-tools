"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = void 0;
var data_download_1 = require("../data-download");
Object.defineProperty(exports, "default", { enumerable: true, get: function () { return data_download_1.ODataDownloadGenerator; } });
//# sourceMappingURL=index.js.map