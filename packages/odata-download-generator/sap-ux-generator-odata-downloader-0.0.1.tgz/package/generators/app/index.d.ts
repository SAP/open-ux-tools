export { ODataDownloadGenerator as default } from '../data-download';
//# sourceMappingURL=index.d.ts.map