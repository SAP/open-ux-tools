/**
 * Class to manage prompt state including caches for external services and reference facets.
 */
export declare class PromptState {
    static externalServiceRequestCache: Record<string, string[]>;
    static entityTypeRefFacetCache: Record<string, string[]>;
    /**
     * Reset the external service request cache.
     *
     * @param extServicePath - Optional specific service path to reset. If not provided, resets entire cache.
     */
    static resetExternalServiceCache(extServicePath?: string): void;
    static resetRefFacetCache(): void;
    static resetServiceCaches(): void;
}
//# sourceMappingURL=prompt-state.d.ts.map