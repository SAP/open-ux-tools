import { Prompts } from '@sap-devx/yeoman-ui-types';
import type { ILogWrapper } from '@sap-ux/fiori-generator-shared';
import type { Logger } from '@sap-ux/logger';
import type { IVSCodeExtLogger, LogLevel } from '@vscode-logging/logger';
import type { GeneratorOptions } from 'yeoman-generator';
import Generator from 'yeoman-generator';
export declare const APP_GENERATOR_MODULE = "@sap/generator-fiori";
/**
 * The root generator for Fiori Elements and Fiori Freestyle generators.
 * All common functionality is implemented here.
 */
export declare class ODataDownloadGenerator extends Generator {
    private readonly vscode;
    private readonly appWizard;
    private static _logger;
    protected generatorVersion: string;
    prompts: Prompts;
    setPromptsCallback: (fn: object) => void;
    private readonly state;
    /**
     * Creates a new ODataDownloadGenerator instance.
     *
     * @param args - Generator arguments passed to yeoman
     * @param opts - Generator options passed to yeoman
     */
    constructor(args: string | string[], opts: GeneratorOptions);
    /**
     * Static getter for the logger.
     *
     * @returns The logger instance
     */
    static get logger(): ILogWrapper & Logger;
    initializing(): Promise<void>;
    prompting(): Promise<void>;
    writing(): Promise<void>;
    /**
     * Shows an error message and throws an exception.
     *
     * @param error - The error message to display
     */
    private _exitOnError;
    /**
     * Configures the vscode logger and yeoman logger to share single wrapper.
     * Set as an option to be passed to sub-gens.
     *
     * @param logLevel - The log level to use
     * @param vscLogger - The VS Code extension logger
     * @param vscode - The VS Code API object
     * @returns The configured log wrapper
     */
    _configureLogging(logLevel: LogLevel, vscLogger: IVSCodeExtLogger, vscode?: object): ILogWrapper;
}
//# sourceMappingURL=odata-download-generator.d.ts.map