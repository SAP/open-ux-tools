import type { ApplicationAccess } from '@sap-ux/project-access';
import type { FioriToolsProxyConfigBackend } from '@sap-ux/ui5-config';
import type { EntityType } from '@sap-ux/vocabularies-types';
import type { Specification } from '@sap/ux-specification/dist/types/src';
import type { PageV4 } from '@sap/ux-specification/dist/types/src/v4';
import type { Answers, CheckboxChoiceOptions } from 'inquirer';
import type { EntitySetsFlat } from './odata-query';
export type SemanticKeyFilter = {
    name: string;
    type: string;
    value: string | undefined;
};
export type ReferencedEntities = {
    listEntity: Entity & {
        semanticKeys: SemanticKeyFilter[];
    };
    pageObjectEntities?: Entity[];
    navPropEntities?: Map<Entity, Entity[]>;
};
export type Entity = {
    entitySetName: string;
    entityPath: string;
    entityType: EntityType | undefined;
    page?: PageV4;
    navPropEntities?: Entity[];
};
/**
 * Type to manage application configuration state.
 */
export type AppConfig = {
    appAccess?: ApplicationAccess;
    specification?: Specification;
    referencedEntities?: ReferencedEntities;
    /**
     * Main service path
     */
    servicePath?: string;
    backendConfig?: FioriToolsProxyConfigBackend;
    /**
     * If the system url + client read from the backend config is available from the system store the matching name will be used to pre-select
     */
    systemName?: {
        value?: string;
    };
    connectPath?: {
        value?: string;
    };
    relatedEntityChoices: {
        choices: CheckboxChoiceOptions<Answers>[];
        entitySetsFlat: EntitySetsFlat;
    };
};
export declare const navPropNameExclusions: string[];
export declare const entityTypeExclusions: string[];
//# sourceMappingURL=types.d.ts.map