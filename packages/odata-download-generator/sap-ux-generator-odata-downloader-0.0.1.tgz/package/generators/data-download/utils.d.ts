import type { ApplicationAccess } from '@sap-ux/project-access';
import { type Specification } from '@sap/ux-specification/dist/types/src';
import type { EntitySetsFlat } from './odata-query';
import type { ReferencedEntities } from './types';
/**
 * Creates an object keyed on entity set name containing expanded results.
 *
 * @param odataResult - The OData result to process
 * @param entitySetsFlat - Map of entity paths to entity set names
 * @param entitySetName - The name of the entity set
 * @returns Object keyed on entity set name containing entity data arrays
 */
export declare function createEntitySetData(odataResult: object | unknown[], entitySetsFlat: EntitySetsFlat, entitySetName: string): {
    [key: string]: object[];
};
/**
 * Load the system from store if available otherwise return as a new system choice.
 *
 * @param systemUrl - The system URL
 * @param client - The client number
 * @returns The system name or 'NewSystemChoice' if not found
 */
export declare function getSystemNameFromStore(systemUrl: string, client?: string | number): Promise<string | undefined>;
/**
 * Load the entity model for processing to determine the odata queries that are relevant for the application.
 *
 * @param appAccess - Application access reference
 * @param specification - The specification instance
 * @param remoteMetadata - The backend service metadata, as distinct to the local metadata
 * @returns The referenced entities or undefined if not found
 */
export declare function getEntityModel(appAccess: ApplicationAccess, specification: Specification, remoteMetadata: string): Promise<ReferencedEntities | undefined>;
//# sourceMappingURL=utils.d.ts.map