import type { ODataService } from '@sap-ux/axios-extension';
import { type SelectedEntityAnswer } from './prompts/prompts';
import type { ReferencedEntities } from './types';
export type EntitySetsFlat = {
    [entityPath: string]: string;
};
/**
 * Builds the expands object used to create an odata query.
 *
 * @param entityPaths - Array of entity paths with their entity set names
 * @returns Object containing expands configuration and entity path parts
 */
export declare function getExpands(entityPaths: {
    entityPath: string;
    entitySetName: string;
}[]): {
    expands: object;
    entityPathParts: string[];
};
/**
 * Create the odata query by expanding and filtering the list entity.
 *
 * @param listEntity - The list entity to query from
 * @param selectedEntities - The selected entities to include in the query
 * @param top - The maximum number of records to return
 * @returns The generated query string
 */
export declare function createQueryFromEntities(listEntity: ReferencedEntities['listEntity'], selectedEntities: SelectedEntityAnswer[], top?: number): {
    query: string;
};
/**
 * Builds an odata query and fetches the data from a backend.
 *
 * @param listEntity - The list entity to query from
 * @param odataService - The OData service to use for fetching
 * @param selectedEntities - The selected entities to include in the query
 * @param top - The maximum number of records to return
 * @returns The fetched OData result
 */
export declare function fetchData(listEntity: ReferencedEntities['listEntity'], odataService: ODataService, selectedEntities: SelectedEntityAnswer[], top?: number): Promise<{
    odataResult: {
        entityData?: [];
        error?: string;
    };
}>;
//# sourceMappingURL=odata-query.d.ts.map