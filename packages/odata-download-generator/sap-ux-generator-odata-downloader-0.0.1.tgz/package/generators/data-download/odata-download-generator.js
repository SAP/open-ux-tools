"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ODataDownloadGenerator = exports.APP_GENERATOR_MODULE = void 0;
const yeoman_ui_types_1 = require("@sap-devx/yeoman-ui-types");
const fiori_generator_shared_1 = require("@sap-ux/fiori-generator-shared");
const odata_service_writer_1 = require("@sap-ux/odata-service-writer");
const project_access_1 = require("@sap-ux/project-access");
const node_path_1 = require("node:path");
const prettify_xml_1 = __importDefault(require("prettify-xml"));
const yeoman_generator_1 = __importDefault(require("yeoman-generator"));
const i18n_1 = require("../utils/i18n");
const prompts_1 = require("./prompts/prompts");
const utils_1 = require("./utils");
const value_help_prompts_1 = require("./prompts/value-help-prompts");
const mockserver_config_writer_1 = require("@sap-ux/mockserver-config-writer");
exports.APP_GENERATOR_MODULE = '@sap/generator-fiori';
/**
 * The root generator for Fiori Elements and Fiori Freestyle generators.
 * All common functionality is implemented here.
 */
class ODataDownloadGenerator extends yeoman_generator_1.default {
    vscode;
    appWizard;
    // The logger is static to allow convenient access from everywhere, cross-cutting concern
    static _logger = fiori_generator_shared_1.DefaultLogger;
    // Generator name for use in telemetry, readmes etc.
    generatorVersion = this.rootGeneratorVersion();
    prompts;
    setPromptsCallback;
    state = {};
    /**
     * Creates a new ODataDownloadGenerator instance.
     *
     * @param args - Generator arguments passed to yeoman
     * @param opts - Generator options passed to yeoman
     */
    constructor(args, opts) {
        super(args, opts, {
            unique: 'namespace'
        });
        // @ts-expect-error no types available
        if (this.env.conflicter) {
            // @ts-expect-error no types available
            this.env.conflicter.force = true;
        }
        this.options.force = true;
        // Generator steps
        this.prompts = new yeoman_ui_types_1.Prompts([
            {
                description: (0, i18n_1.t)('steps.odataDownloader.description'),
                name: (0, i18n_1.t)('steps.odataDownloader.name')
            },
            {
                description: (0, i18n_1.t)('steps.valueHelpSelection.description'),
                name: (0, i18n_1.t)('steps.valueHelpSelection.name')
            }
        ]);
        this.setPromptsCallback = (fn) => {
            if (this.prompts) {
                this.prompts.setCallback(fn);
            }
        };
    }
    /**
     * Static getter for the logger.
     *
     * @returns The logger instance
     */
    static get logger() {
        return ODataDownloadGenerator._logger;
    }
    async initializing() {
        // Ensure i18n bundles are loaded, default loading is unreliable
        await (0, i18n_1.initI18nODataDownloadGenerator)();
        ODataDownloadGenerator._logger = this._configureLogging(this.options.logLevel, this.options.logger, this.options.vscode);
    }
    async prompting() {
        try {
            const { answers: { application, odataQueryResult, odataServiceAnswers }, questions } = await (0, prompts_1.getODataDownloaderPrompts)();
            const promptAnswers = (await this.prompt(questions));
            this.state.entityOData = odataQueryResult.odata;
            this.state.entityPropertyToEntitySet = application.relatedEntityChoices.entitySetsFlat;
            this.state.appRootPath = application.appAccess?.getAppRoot();
            this.state.mainServicePath = odataServiceAnswers.servicePath;
            this.state.mainServiceName = application.appAccess?.app.mainService;
            this.state.appEntities = application.referencedEntities;
            if (this.state.appRootPath) {
                this.state.mockServerConfig = await (0, project_access_1.getMockServerConfig)(this.state.appRootPath);
                let serviceConfig;
                if (this.state.mockServerConfig?.services) {
                    ODataDownloadGenerator.logger.debug(`Mock config: ${JSON.stringify(this.state.mockServerConfig)}`);
                    // Find the matching service from mock config ignoring leading and trailing '/'
                    serviceConfig = this.state.mockServerConfig.services.find((service) => service.urlPath.replaceAll(/(^\/)|(\/$)/g, '') ===
                        this.state.mainServicePath?.replaceAll(/(^\/)|(\/$)/g, ''));
                }
                // If no config found use the default location for mock data
                this.state.mockDataRootPath =
                    serviceConfig?.mockdataPath ?? (0, node_path_1.join)(project_access_1.DirName.Webapp, project_access_1.DirName.LocalService, project_access_1.DirName.Mockdata);
            }
            this.state.updateMainServiceMetadata = promptAnswers[prompts_1.promptNames.updateMainServiceMetadata];
            this.state.mainServiceMetadata = odataServiceAnswers.metadata;
            if (odataServiceAnswers.servicePath && odataServiceAnswers.metadata) {
                const { questions: valueHelpQuestions, valueHelpData } = (0, value_help_prompts_1.getValueHelpSelectionPrompt)(odataServiceAnswers.servicePath, odataServiceAnswers.metadata, odataServiceAnswers.connectedSystem?.serviceProvider);
                await this.prompt(valueHelpQuestions);
                this.state.valueHelpData = valueHelpData;
            }
        }
        catch (error) {
            // Fatal prompting error
            ODataDownloadGenerator.logger.error(error);
            this._exitOnError(error);
        }
    }
    async writing() {
        if (this.state.appRootPath) {
            if (this.state.entityOData && this.state.entityPropertyToEntitySet && this.state.appEntities) {
                try {
                    // Set target dir to mock data path
                    this.destinationRoot((0, node_path_1.join)(this.state.appRootPath));
                    const entityFileData = (0, utils_1.createEntitySetData)(this.state.entityOData, this.state.entityPropertyToEntitySet, this.state.appEntities.listEntity.entitySetName);
                    ODataDownloadGenerator.logger.info((0, i18n_1.t)('info.entityFilesToBeGenerated', { entities: Object.keys(entityFileData).join(', ') }));
                    Object.entries(entityFileData).forEach(([entityName, entityData]) => {
                        // Writes relative to destination root path
                        this.writeDestinationJSON((0, node_path_1.join)(this.state.mockDataRootPath, `${entityName}.json`), entityData);
                    });
                }
                catch (error) {
                    ODataDownloadGenerator.logger.error(error);
                }
            }
            else {
                ODataDownloadGenerator.logger.info((0, i18n_1.t)('info.noServiceEntityData'));
            }
            // Write value help data files
            if (this.state.valueHelpData?.length) {
                // Service metadata writing will create the necessary data folders
                // Passing the webapp folder might be invalid, but we cant pass the path from the mocker server here.
                const webappPath = (0, node_path_1.join)(this.state.appRootPath, project_access_1.DirName.Webapp);
                await (0, odata_service_writer_1.writeExternalServiceMetadata)(this.fs, webappPath, this.state.valueHelpData, this.state.mainServiceName, this.state.mainServicePath);
                // Update the mock server config if `resolveExternalServiceReferences` is not already present
                if (this.state.mockServerConfig) {
                    const config = {
                        webappPath: webappPath,
                        // Since ui5-mock.yaml already exists, set 'skip' to skip package.json file updates
                        packageJsonConfig: {
                            skip: true
                        },
                        // Set 'overwrite' to true to overwrite services data in YAML files
                        ui5MockYamlConfig: {
                            overwrite: true
                        }
                    };
                    if (config.ui5MockYamlConfig && this.state.mainServiceName) {
                        config.ui5MockYamlConfig.resolveExternalServiceReferences = {
                            [this.state.mainServiceName]: true
                        };
                        // Regenerate mockserver middleware for ui5-mock.yaml by overwriting
                        await (0, mockserver_config_writer_1.generateMockserverConfig)(this.state.appRootPath, config, this.fs);
                    }
                }
            }
            else {
                ODataDownloadGenerator.logger.info((0, i18n_1.t)('info.noValueHelpData'));
            }
            // Update the metadata
            if (this.state.updateMainServiceMetadata && this.state.mainServiceMetadata && this.state.mainServiceName) {
                const mainServiceMetadataPath = (0, node_path_1.join)(this.state.appRootPath, project_access_1.DirName.Webapp, project_access_1.DirName.LocalService, this.state.mainServiceName, 'metadata.xml');
                this.writeDestination(mainServiceMetadataPath, (0, prettify_xml_1.default)(this.state.mainServiceMetadata, { indent: 4 }));
            }
        }
    }
    /**
     * Shows an error message and throws an exception.
     *
     * @param error - The error message to display
     */
    _exitOnError(error) {
        if ((0, fiori_generator_shared_1.getHostEnvironment)() !== fiori_generator_shared_1.hostEnvironment.cli) {
            this.appWizard?.showError(error, yeoman_ui_types_1.MessageType.notification);
        }
        throw new Error(error);
    }
    /**
     * Configures the vscode logger and yeoman logger to share single wrapper.
     * Set as an option to be passed to sub-gens.
     *
     * @param logLevel - The log level to use
     * @param vscLogger - The VS Code extension logger
     * @param vscode - The VS Code API object
     * @returns The configured log wrapper
     */
    _configureLogging(logLevel, vscLogger, vscode) {
        const logWrapper = new fiori_generator_shared_1.LogWrapper(this.rootGeneratorName(), this.log, logLevel, // Only used for CLI
        vscLogger, vscode);
        logWrapper.info((0, i18n_1.t)('info.loggingInitialised', { logLevel: logWrapper.getLogLevel() }));
        return logWrapper;
    }
}
exports.ODataDownloadGenerator = ODataDownloadGenerator;
//# sourceMappingURL=odata-download-generator.js.map