"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.entityTypeExclusions = exports.navPropNameExclusions = void 0;
exports.navPropNameExclusions = ['DraftAdministrativeData', 'SiblingEntity'];
exports.entityTypeExclusions = ['I_DraftAdministrativeData'];
//# sourceMappingURL=types.js.map