"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValueHelpSelectionPrompt = getValueHelpSelectionPrompt;
const annotation_converter_1 = require("@sap-ux/annotation-converter");
const edmx_parser_1 = require("@sap-ux/edmx-parser");
const odata_service_writer_1 = require("@sap-ux/odata-service-writer");
const deepmerge_1 = __importDefault(require("deepmerge"));
const node_path_1 = require("node:path");
const i18n_1 = require("../../utils/i18n");
const prompt_state_1 = require("../prompt-state");
const types_1 = require("../types");
/**
 * Gets the value help selection prompt.
 *
 * @param servicePath - The service path
 * @param metadata - The service metadata
 * @param abapServiceProvider - The ABAP service provider
 * @returns Object containing questions and value help data reference
 */
function getValueHelpSelectionPrompt(servicePath, metadata, abapServiceProvider) {
    prompt_state_1.PromptState.resetExternalServiceCache();
    const valueHelpChoices = getValueHelpChoices(servicePath, metadata);
    const valueHelpData = [];
    const vhSelectionQuestion = {
        name: 'valueHelpSelection',
        type: 'checkbox',
        message: (0, i18n_1.t)('prompts.valueHelpSelection.message'),
        choices: () => valueHelpChoices,
        validate: async (selectedValueHelps) => {
            if (!selectedValueHelps || selectedValueHelps.length === 0) {
                prompt_state_1.PromptState.resetExternalServiceCache();
                return true;
            }
            const valueHelpMetadata = await getExternalServiceMetadata(selectedValueHelps, abapServiceProvider);
            const merged = (0, deepmerge_1.default)(valueHelpData, valueHelpMetadata);
            valueHelpData.length = 0;
            valueHelpData.push(...merged);
            await getExternalServiceEntityData(valueHelpData, abapServiceProvider);
            return true;
        }
    };
    return { questions: [vhSelectionQuestion], valueHelpData };
}
/**
 * Fetches entity data for selected external services.
 *
 * @param selectedValueHelpRefs - The selected external service references
 * @param abapServiceProvider - The ABAP service provider
 * @returns Array of external services with entity data
 */
async function getExternalServiceEntityData(selectedValueHelpRefs, abapServiceProvider) {
    const externalServiceEntityData = [];
    const reqConfig = {
        transformResponse: (data) => {
            if (typeof data === 'string') {
                return JSON.parse(data);
            }
            return data;
        }
    };
    const allPromises = selectedValueHelpRefs.map(async (externalServiceRef) => {
        const valueHelpEntityData = externalServiceRef;
        const [servicePath] = valueHelpEntityData.path.split(';');
        // Create a request cache entry
        prompt_state_1.PromptState.externalServiceRequestCache[servicePath] ??= [];
        const serviceMetadata = (0, annotation_converter_1.convert)((0, edmx_parser_1.parse)(externalServiceRef.metadata));
        const entitySets = serviceMetadata.entitySets;
        const requestPromises = entitySets.map(async (entitySet) => {
            const entitySetName = entitySet.name;
            // If we already have this entity data dont request again
            if (prompt_state_1.PromptState.externalServiceRequestCache[servicePath].includes(entitySetName)) {
                return;
            }
            prompt_state_1.PromptState.externalServiceRequestCache[servicePath].push(entitySetName);
            const response = await abapServiceProvider.get((0, node_path_1.join)(valueHelpEntityData.path, entitySetName), reqConfig);
            valueHelpEntityData.entityData = valueHelpEntityData.entityData ?? [];
            valueHelpEntityData.entityData?.push({
                entitySetName,
                items: response.data.value
            });
        });
        await Promise.allSettled(requestPromises);
        if (valueHelpEntityData.entityData) {
            externalServiceEntityData.push(valueHelpEntityData);
        }
    });
    await Promise.allSettled(allPromises);
    return externalServiceEntityData;
}
/**
 * Fetches metadata for selected external services.
 *
 * @param selectedValueHelps - The selected value help references
 * @param abapServiceProvider - The ABAP service provider
 * @returns Array of external services with metadata
 */
async function getExternalServiceMetadata(selectedValueHelps, abapServiceProvider) {
    const flatExtSerRefs = selectedValueHelps.flat();
    const extServiceData = await abapServiceProvider.fetchExternalServices(flatExtSerRefs);
    return extServiceData;
}
/**
 * Gets the checkbox choices for value help selection.
 *
 * @param servicePath - The service path
 * @param metadata - The service metadata
 * @returns Array of checkbox choices for value help entities
 */
function getValueHelpChoices(servicePath, metadata) {
    const externalServiceRefs = (0, odata_service_writer_1.getExternalServiceReferences)(servicePath, metadata, []);
    // Build path -> entity -> refs map in a single pass
    const choiceNameByPathAndEntity = {};
    for (const ref of externalServiceRefs) {
        if (ref.type === 'value-list') {
            // Skip specific target names
            if (types_1.entityTypeExclusions.includes(ref.target)) {
                continue;
            }
            const [vhServicePath] = ref.value.split(';');
            const targetEntity = ref.target.split('/').pop();
            if (targetEntity) {
                choiceNameByPathAndEntity[vhServicePath] ??= {};
                choiceNameByPathAndEntity[vhServicePath][targetEntity] ??= [];
                choiceNameByPathAndEntity[vhServicePath][targetEntity].push(ref);
            }
        }
        else if (ref.type === 'code-list') {
            // Put all code list entities for the same service on the same choice
            choiceNameByPathAndEntity[ref.value] ??= {};
            choiceNameByPathAndEntity[ref.value]['Code list'] ??= [];
            choiceNameByPathAndEntity[ref.value]['Code list'].push(ref);
        }
    }
    // Create choices
    const choices = [];
    for (const targetEntities of Object.values(choiceNameByPathAndEntity)) {
        for (const [targetEntity, entityRefs] of Object.entries(targetEntities)) {
            const choiceNameTargets = entityRefs
                .map((entityRef) => {
                if (entityRef.type === 'value-list') {
                    return entityRef.target.replace(/\/[^/]*$/, '');
                }
                else if (entityRef.type === 'code-list' && entityRef.collectionPath) {
                    return entityRef.collectionPath;
                }
                return undefined;
            })
                .filter((t) => t !== undefined);
            choices.push({ name: `${targetEntity} (${choiceNameTargets.join()})`, value: entityRefs });
        }
    }
    return choices.sort((a, b) => a.name.localeCompare(b.name));
}
//# sourceMappingURL=value-help-prompts.js.map