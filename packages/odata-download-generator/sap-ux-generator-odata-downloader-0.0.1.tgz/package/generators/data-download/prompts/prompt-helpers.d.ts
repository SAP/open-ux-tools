import type { OdataServiceAnswers } from '@sap-ux/odata-service-inquirer';
import type { ServiceSpecification, ApplicationAccess } from '@sap-ux/project-access';
import type { CheckboxChoiceOptions } from 'inquirer';
import { type EntitySetsFlat } from '../odata-query';
import type { SelectedEntityAnswer } from './prompts';
import type { AppConfig, Entity } from '../types';
import type { Specification } from '@sap/ux-specification/dist/types/src';
/**
 * Fetches OData from the backend service.
 *
 * @param odataService - The OData service answers containing connection details
 * @param appConfig - The application configuration
 * @param selectedEntities - The selected entities to fetch data for
 * @returns The query result or an error message
 */
export declare function getData(odataService: Partial<OdataServiceAnswers>, appConfig: AppConfig, selectedEntities: SelectedEntityAnswer[]): Promise<{
    odataQueryResult: [];
} | string>;
export type Expands = {
    [entityPath: string]: {
        expand: Expands;
        selected?: boolean;
        fullPath: string;
    };
};
/**
 * Create an expand/entity selection list from the specified entities nav properties.
 *
 * @param rootEntity - The root entity to create choices for
 * @param pageObjectEntities - Optional page object entities for pre-selection
 * @returns Object containing entity sets flat map and checkbox choices, or undefined
 */
export declare function createEntityChoices(rootEntity: Entity, pageObjectEntities?: Entity[]): {
    entitySetsFlat: EntitySetsFlat;
    choices: CheckboxChoiceOptions<SelectedEntityAnswer>[];
} | undefined;
/**
 * Get the service path and service name from the service.
 *
 * @param appRoot - The application root path
 * @param service - The service specification
 * @returns Object containing service path and system name
 */
export declare function getServiceDetails(appRoot: string, service: ServiceSpecification): Promise<{
    servicePath: string | undefined;
    systemName: string | undefined;
}>;
/**
 * Retrieves the Specification object.
 *
 * @param appAccess - The application access reference
 * @returns A promise that resolves to a Specification object or an error string
 */
export declare function getSpecification(appAccess: ApplicationAccess): Promise<Specification | string>;
//# sourceMappingURL=prompt-helpers.d.ts.map