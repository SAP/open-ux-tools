import type { OdataServiceAnswers } from '@sap-ux/odata-service-inquirer';
import type { Question } from 'inquirer';
import type { AppConfig } from '../types';
export declare const promptNames: {
    appSelection: string;
    toggleSelection: string;
    relatedEntitySelection: string;
    skipDataDownload: string;
    updateMainServiceMetadata: string;
};
export type SelectedEntityAnswer = {
    fullPath: string;
    entity: {
        entityPath: string;
        entitySetName: string;
        defaultSelected?: boolean;
    };
};
/**
 * Gets all prompts for the OData downloader flow.
 *
 * @returns Object containing questions and answer references
 */
export declare function getODataDownloaderPrompts(): Promise<{
    questions: Question[];
    answers: {
        application: AppConfig;
        odataQueryResult: {
            odata: [];
        };
        odataServiceAnswers: Partial<OdataServiceAnswers>;
    };
}>;
//# sourceMappingURL=prompts.d.ts.map