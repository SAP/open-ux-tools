"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.promptNames = void 0;
exports.getODataDownloaderPrompts = getODataDownloaderPrompts;
const yeoman_ui_types_1 = require("@sap-devx/yeoman-ui-types");
const fiori_generator_shared_1 = require("@sap-ux/fiori-generator-shared");
const inquirer_common_1 = require("@sap-ux/inquirer-common");
const odata_service_inquirer_1 = require("@sap-ux/odata-service-inquirer");
const project_access_1 = require("@sap-ux/project-access");
const i18n_1 = require("../../utils/i18n");
const odata_download_generator_1 = require("../odata-download-generator");
const utils_1 = require("../utils");
const prompt_helpers_1 = require("./prompt-helpers");
const prompt_state_1 = require("../prompt-state");
let debounceTimer;
const debouncedGetData = (...args) => {
    return new Promise((resolve) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => resolve(await (0, prompt_helpers_1.getData)(...args)), 1000);
    });
};
exports.promptNames = {
    appSelection: 'appSelection',
    toggleSelection: 'toggleSelection',
    relatedEntitySelection: 'relatedEntitySelection',
    skipDataDownload: 'skipDataDownload',
    updateMainServiceMetadata: 'updateMainServiceMetadata'
};
const invalidEntityKeyFilterChars = ['.'];
/**
 * Validates entity key input and fetches OData if valid.
 *
 * @param answers - The current answers object
 * @param odataServiceAnswers - The OData service answers
 * @param appConfig - The application configuration
 * @returns Validation result or fetched data
 */
async function validateKeysAndFetchData(answers, odataServiceAnswers, appConfig) {
    const hasKeyInput = Object.entries(answers).find(([key, value]) => key.startsWith('entityKeyIdx:') && !!value?.trim());
    if (!hasKeyInput) {
        return (0, i18n_1.t)('prompts.skipDataDownload.validation.keyRequired');
    }
    let entitySelections = [];
    // Prevents previous answers from being used when the app is switched and the new app has no entity selections (no nav props)
    if (appConfig.relatedEntityChoices?.choices?.length) {
        entitySelections = answers[exports.promptNames.relatedEntitySelection];
    }
    const result = await debouncedGetData(odataServiceAnswers, appConfig, entitySelections);
    if (typeof result === 'string') {
        return result;
    }
    return result;
}
/**
 * Reset the values of the passed app config reference or initialises a new reference.
 * Preserves the original object references. Reset any caches.
 *
 * @param appConfig - The app configuration to reset
 * @returns A null state app config
 */
function resetAppConfig(appConfig) {
    prompt_state_1.PromptState.resetServiceCaches();
    appConfig.appAccess = undefined;
    appConfig.referencedEntities = undefined;
    appConfig.servicePath = undefined;
    if (appConfig.systemName) {
        appConfig.systemName.value = undefined;
    }
    appConfig.relatedEntityChoices.choices = [];
    appConfig.relatedEntityChoices.entitySetsFlat = {};
    return appConfig;
}
/**
 * Gets all prompts for the OData downloader flow.
 *
 * @returns Object containing questions and answer references
 */
async function getODataDownloaderPrompts() {
    const selectSourceQuestions = [];
    // Local state
    const appConfig = {
        appAccess: undefined,
        referencedEntities: undefined,
        servicePath: undefined,
        systemName: { value: undefined, connectPath: undefined },
        relatedEntityChoices: {
            choices: [],
            entitySetsFlat: {}
        }
    };
    const servicePaths = [];
    const appSelectionQuestion = getAppSelectionPrompt(appConfig, servicePaths);
    const systemSelectionQuestions = await (0, odata_service_inquirer_1.getSystemSelectionQuestions)({
        datasourceType: {
            includeNone: false
        },
        systemSelection: {
            includeCloudFoundryAbapEnvChoice: false,
            defaultChoice: appConfig.systemName,
            hideNewSystem: true
        },
        serviceSelection: {
            serviceFilter: servicePaths,
            requiredOdataVersion: odata_service_inquirer_1.OdataVersion.v4
        }
    }, (0, fiori_generator_shared_1.getHostEnvironment)() !== fiori_generator_shared_1.hostEnvironment.cli, odata_download_generator_1.ODataDownloadGenerator.logger);
    // Dont show the system/service selection prompts unless we have a valid app loaded
    systemSelectionQuestions.prompts = (0, inquirer_common_1.withCondition)(systemSelectionQuestions.prompts, () => !!appConfig.appAccess);
    const odataQueryResult = {
        odata: []
    };
    const resetSelectionPrompt = getResetSelectionPrompt(appConfig, appConfig.relatedEntityChoices);
    const keyPrompts = getKeyPrompts(5, appConfig, systemSelectionQuestions.answers, odataQueryResult);
    const relatedEntitySelectionQuestion = getEntitySelectionPrompt(appConfig.relatedEntityChoices, systemSelectionQuestions.answers, appConfig, odataQueryResult);
    selectSourceQuestions.push(appSelectionQuestion, ...systemSelectionQuestions.prompts, getUpdateMainServiceMetadataPrompt(systemSelectionQuestions.answers, appConfig), getSkipDataDownloadPrompt(systemSelectionQuestions.answers, appConfig), ...keyPrompts, resetSelectionPrompt, relatedEntitySelectionQuestion);
    return {
        questions: selectSourceQuestions,
        answers: { application: appConfig, odataQueryResult, odataServiceAnswers: systemSelectionQuestions.answers }
    };
}
/**
 * Gets the app selection prompt.
 *
 * @param appConfig - The application configuration reference
 * @param servicePaths - Array to store service paths
 * @returns The app selection input question
 */
function getAppSelectionPrompt(appConfig, servicePaths) {
    return {
        type: 'input',
        guiType: 'folder-browser',
        name: exports.promptNames.appSelection,
        message: (0, i18n_1.t)('prompts.appSelection.message'),
        default: (answers) => answers.appSelection ?? appConfig.appAccess?.app.appRoot,
        guiOptions: { mandatory: true, breadcrumb: (0, i18n_1.t)('prompts.appSelection.breadcrumb') },
        validate: async (appPath) => {
            if (!appPath) {
                return false;
            }
            // Already set, adding prompts will retrigger validation
            if (appPath === appConfig.appAccess?.app.appRoot) {
                return true;
            }
            // Selected app has changed reset local state
            servicePaths.length = 0;
            resetAppConfig(appConfig);
            // validate application exists at path
            let appAccess;
            try {
                appAccess = await (0, project_access_1.createApplicationAccess)(appPath);
            }
            catch (error) {
                let errorMsg = error;
                if (error instanceof Error) {
                    errorMsg = error.message;
                }
                odata_download_generator_1.ODataDownloadGenerator.logger.error((0, i18n_1.t)('prompts.appSelection.validation.selectedPathDoesNotContainValidApp', { error: errorMsg }));
                return `${(0, i18n_1.t)('prompts.appSelection.validation.selectedPathDoesNotContainValidApp')}${(0, i18n_1.t)('texts.seeLogForDetails')}`;
            }
            // currently only the main service is supported
            const mainService = appAccess.app.services[appAccess.app.mainService ?? 'mainService'];
            if (!mainService?.odataVersion?.startsWith('4.')) {
                return (0, i18n_1.t)('prompts.appSelection.validation.appMainServiceOdataVersionNotSupported', {
                    serviceOdataVersion: mainService.odataVersion
                });
            }
            const specResult = await (0, prompt_helpers_1.getSpecification)(appAccess);
            if (typeof specResult === 'string') {
                return specResult;
            }
            appConfig.appAccess = appAccess;
            appConfig.specification = specResult;
            const { servicePath, systemName } = await (0, prompt_helpers_1.getServiceDetails)(appAccess.app.appRoot, mainService);
            if (servicePath) {
                appConfig.servicePath = servicePath;
                servicePaths.push(servicePath);
            }
            if (appConfig.systemName) {
                appConfig.systemName.value = systemName;
                appConfig.systemName.connectPath = servicePath;
            }
            return true;
        }
    };
}
/**
 * Gets the entity selection prompt.
 *
 * @param relatedEntityChoices - Object containing choices and entitySetsFlat
 * @param relatedEntityChoices.choices - The checkbox choices for entity selection
 * @param relatedEntityChoices.entitySetsFlat - Map of entity paths to entity set names
 * @param odataServiceAnswers - The OData service answers object containing the connection configuration and service metadata
 * @param appConfig - The application configuration object retrieved from ux-specification containing app settings
 * @param odataQueryResult - An object that serves as a container for storing the OData query results
 * @param odataQueryResult.odata - The array of OData entities that were downloaded from the service
 * @returns The checkbox question for entity selection
 */
function getEntitySelectionPrompt(relatedEntityChoices, odataServiceAnswers, appConfig, odataQueryResult) {
    let result;
    return {
        when: async (_answers) => relatedEntityChoices.choices.length > 0,
        name: exports.promptNames.relatedEntitySelection,
        type: 'checkbox',
        guiOptions: {
            applyDefaultWhenDirty: true // Required to update when reset of selection is triggered
        },
        message: (0, i18n_1.t)('prompts.relatedEntitySelection.message'),
        choices: () => relatedEntityChoices.choices,
        validate: async (selectedEntities, answers) => {
            // Set `checked` to avoid deselection when re-running `default`.
            selectedEntities.forEach((selectedEntity) => {
                const selectedEntityChoice = relatedEntityChoices.choices.find((entityChoice) => entityChoice.value.fullPath === selectedEntity.fullPath);
                if (selectedEntityChoice) {
                    selectedEntityChoice.checked = true;
                }
            });
            if (answers && !answers[exports.promptNames.skipDataDownload]?.[0]) {
                result = await validateKeysAndFetchData(answers, odataServiceAnswers, appConfig);
                if (typeof result === 'string') {
                    return result;
                }
                odataQueryResult.odata = result.odataQueryResult;
            }
            return true;
        },
        additionalMessages: () => {
            if (result && typeof result !== 'string') {
                return {
                    message: (0, i18n_1.t)('prompts.skipDataDownload.querySuccess', {
                        count: result.odataQueryResult.length
                    }),
                    severity: yeoman_ui_types_1.Severity.information
                };
            }
            return undefined;
        }
    };
}
/**
 * Gets the reset selection prompt. This prompt is responsible for loading the entity choices.
 *
 * @param appConfig - The application configuration
 * @param relatedEntityChoices - Object containing choices and entitySetsFlat
 * @param relatedEntityChoices.choices - The checkbox choices for entity selection
 * @param relatedEntityChoices.entitySetsFlat - Map of entity paths to entity set names
 * @returns The reset selection confirm question
 */
function getResetSelectionPrompt(appConfig, relatedEntityChoices) {
    let previousServicePath;
    let previousSystemName;
    let previousReset;
    const toggleSelectionPrompt = {
        when: () => {
            // System was changed, rebuild choices even if service path is the same, otherwise if service is different
            if (previousSystemName !== appConfig.systemName?.value || appConfig.servicePath !== previousServicePath) {
                if (appConfig.referencedEntities?.listEntity) {
                    const entityChoices = (0, prompt_helpers_1.createEntityChoices)(appConfig.referencedEntities.listEntity, appConfig.referencedEntities.pageObjectEntities);
                    if (entityChoices) {
                        relatedEntityChoices.choices = entityChoices.choices;
                        Object.assign(relatedEntityChoices.entitySetsFlat, entityChoices.entitySetsFlat);
                    }
                }
                previousServicePath = appConfig.servicePath;
                previousSystemName = appConfig.systemName?.value;
            }
            return relatedEntityChoices.choices.length > 0;
        },
        name: exports.promptNames.toggleSelection,
        type: 'confirm',
        message: (0, i18n_1.t)('prompts.toggleSelection.message'),
        labelTrue: (0, i18n_1.t)('prompts.toggleSelection.labelTrue'),
        labelFalse: (0, i18n_1.t)('prompts.toggleSelection.labelFalse'),
        default: false,
        validate: (reset) => {
            // Dont apply a reset unless the value was changed as this validate function is triggered by any earlier prompt inputs
            if (reset !== previousReset) {
                relatedEntityChoices.choices.forEach((entityChoice) => {
                    const entityChoiceValue = entityChoice.value;
                    entityChoice.checked = reset === false ? entityChoiceValue.entity.defaultSelected : false; // Restore default selection
                });
                previousReset = reset;
            }
            return true;
        }
    };
    return toggleSelectionPrompt;
}
/**
 * Get the prompt for keys.
 *
 * @param size - The number of key prompts to generate
 * @param appConfig - The application configuration
 * @param odataServiceAnswers - The OData service answers
 * @param odataQueryResult - Object to store query results
 * @param odataQueryResult.odata - The OData query results array
 * @returns Array of input questions for key entry
 */
function getKeyPrompts(size, appConfig, odataServiceAnswers, odataQueryResult) {
    const questions = [];
    let result;
    let lastKeyPart = 0;
    const getEntityKeyInputPrompt = (keypart) => ({
        when: async () => {
            /* !answers?.[promptNames.skipDataDownload]?.[0] && */
            const showPrompt = !!appConfig.referencedEntities?.listEntity.semanticKeys[keypart]?.name;
            // Store the index of the last shown prompt so we can run the query on this one only
            if (showPrompt && keypart > lastKeyPart) {
                lastKeyPart = keypart;
            }
            return showPrompt;
        },
        name: `entityKeyIdx:${keypart}`,
        message: () => (0, i18n_1.t)('prompts.entityKey.message', {
            keyName: appConfig.referencedEntities?.listEntity.semanticKeys[keypart]?.name
        }),
        type: 'input',
        guiOptions: {
            hint: (0, i18n_1.t)('prompts.entityKey.hint')
        },
        validate: async (keyValue, answers) => {
            if (invalidEntityKeyFilterChars.includes(keyValue)) {
                return (0, i18n_1.t)('prompts.entityKey.validation.invalidKeyValueChars', {
                    chars: invalidEntityKeyFilterChars.join()
                });
            }
            const keyRef = appConfig.referencedEntities?.listEntity.semanticKeys[keypart];
            // Clear key values
            if (!keyValue && keyRef) {
                delete keyRef.value;
            }
            if (keyRef) {
                if (keyRef.type === 'Edm.Boolean') {
                    try {
                        keyRef.value = JSON.parse(keyValue);
                    }
                    catch {
                        return (0, i18n_1.t)('prompts.entityKey.validation.invalidBooleanValue');
                    }
                }
                else {
                    keyRef.value = keyValue.trim();
                }
            }
            const filterAndParts = keyValue.split(',');
            // Dont validate as range if its a UUID, its not supported
            if (keyRef?.type !== 'Edm.UUID') {
                for (const filterPart of filterAndParts) {
                    const filterRangeParts = filterPart.split('-');
                    if (filterRangeParts.length > 2) {
                        return (0, i18n_1.t)('prompts.entityKey.validation.invalidRangeSpecified');
                    }
                }
            }
            // In case there are no entities we can also trigger the data request from the last key input
            if (answers &&
                !appConfig.relatedEntityChoices?.choices?.length &&
                keypart === lastKeyPart &&
                !answers[exports.promptNames.skipDataDownload]?.[0] &&
                !!appConfig.referencedEntities?.listEntity.semanticKeys[keypart]?.name) {
                result = await validateKeysAndFetchData(answers, odataServiceAnswers, appConfig);
                if (typeof result === 'string') {
                    return result;
                }
                odataQueryResult.odata = result.odataQueryResult;
            }
            return true;
        }
    });
    // Generate a prompt for each key we need input for
    for (let i = 0; i < size; i++) {
        questions.push(getEntityKeyInputPrompt(i));
    }
    return questions;
}
/**
 * Gets the confirm download prompt that triggers data fetch.
 *
 * @param odataServiceAnswers - The OData service answers
 * @param appConfig
 * @returns The confirm download question
 */
function getSkipDataDownloadPrompt(odataServiceAnswers, appConfig) {
    return {
        when: () => {
            return !!odataServiceAnswers.metadata && !!appConfig.servicePath; // Only show when we have a valid app with service metadata
        },
        name: exports.promptNames.skipDataDownload,
        type: 'checkbox',
        message: (0, i18n_1.t)('prompts.skipDataDownload.message'),
        default: false,
        choices: [
            {
                name: 'Skip data download',
                value: 'skipDownload',
                checked: false
            }
        ]
    };
}
/**
 * Gets the prompt for updating main service metadata.
 *
 * @param odataServiceAnswers - The OData service answers
 * @param appConfig - The application configuration
 * @returns The confirm question for updating metadata
 */
function getUpdateMainServiceMetadataPrompt(odataServiceAnswers, appConfig) {
    const question = {
        when: async () => {
            // Use this when condition to load the entity data
            if (appConfig.appAccess && appConfig.specification && odataServiceAnswers?.metadata) {
                appConfig.referencedEntities = await (0, utils_1.getEntityModel)(appConfig.appAccess, appConfig.specification, odataServiceAnswers.metadata);
                return true;
            }
            return false;
        },
        name: exports.promptNames.updateMainServiceMetadata,
        type: 'confirm',
        message: (0, i18n_1.t)('prompts.updateMainServiceMetadata.message'),
        default: false
    };
    return question;
}
//# sourceMappingURL=prompts.js.map