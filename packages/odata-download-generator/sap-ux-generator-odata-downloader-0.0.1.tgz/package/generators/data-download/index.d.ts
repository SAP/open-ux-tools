export * from './odata-download-generator';
//# sourceMappingURL=index.d.ts.map