"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEntitySetData = createEntitySetData;
exports.getSystemNameFromStore = getSystemNameFromStore;
exports.getEntityModel = getEntityModel;
const annotation_converter_1 = require("@sap-ux/annotation-converter");
const edmx_parser_1 = require("@sap-ux/edmx-parser");
const store_1 = require("@sap-ux/store");
const src_1 = require("@sap/ux-specification/dist/types/src");
const deepmerge_1 = __importDefault(require("deepmerge"));
const i18n_1 = require("../utils/i18n");
const odata_download_generator_1 = require("./odata-download-generator");
const types_1 = require("./types");
/**
 * Deep equality check using JSON.stringify.
 * Suitable for OData entities which have consistent key ordering from the server.
 *
 * @param a - The first value to be compared for equality
 * @param b - The second value to be compared for equality
 * @returns Returns true if the JSON string representations of both values are identical, false otherwise
 */
const jsonEqual = (a, b) => JSON.stringify(a) === JSON.stringify(b);
/**
 * Deepmerge options to merge array properties by removing dups and concatenating.
 */
const mergeOptions = {
    arrayMerge: (destArray, srcArray) => {
        const combined = [...destArray, ...srcArray];
        return combined.filter((item, idx) => combined.findIndex((other) => jsonEqual(item, other)) === idx);
    }
};
/**
 * Creates an object keyed on entity set name containing expanded results.
 *
 * @param odataResult - The OData result to process
 * @param entitySetsFlat - Map of entity paths to entity set names
 * @param entitySetName - The name of the entity set
 * @returns Object keyed on entity set name containing entity data arrays
 */
function createEntitySetData(odataResult, entitySetsFlat, entitySetName) {
    const resultDataByEntitySet = {};
    const odataRestulAsArray = Array.isArray(odataResult)
        ? odataResult
        : [odataResult];
    // Each entry is of the same entity set data
    odataRestulAsArray.forEach((resultEntry) => {
        Object.entries(entitySetsFlat).forEach(([entityPath, entitySetName]) => {
            // There are nested expanded entities
            if (resultEntry[entityPath]) {
                const entitySetData = createEntitySetData(resultEntry[entityPath], entitySetsFlat, entitySetName);
                Object.assign(resultDataByEntitySet, (0, deepmerge_1.default)(resultDataByEntitySet, entitySetData, mergeOptions));
                // Since we have assigned the property value to its own entity set property we can remove it from the parent (to prevent dups and file bloat)
                delete resultEntry[entityPath];
            }
        });
        if (resultDataByEntitySet[entitySetName]) {
            // prevent duplicates, this would break the mock data server but can be returned from queries
            const found = resultDataByEntitySet[entitySetName].find((entity) => jsonEqual(entity, resultEntry));
            if (!found) {
                resultDataByEntitySet[entitySetName].push(resultEntry);
            }
        }
        else {
            resultDataByEntitySet[entitySetName] = [resultEntry];
        }
    });
    return resultDataByEntitySet;
}
/**
 * Load the system from store if available otherwise return as a new system choice.
 *
 * @param systemUrl - The system URL
 * @param client - The client number
 * @returns The system name or 'NewSystemChoice' if not found
 */
async function getSystemNameFromStore(systemUrl, client) {
    const systemStore = await (0, store_1.getService)({
        logger: odata_download_generator_1.ODataDownloadGenerator.logger,
        entityName: 'system'
    });
    if (typeof client === 'number') {
        client = String(client);
    }
    const system = await systemStore.read(new store_1.BackendSystemKey({ url: systemUrl, client }));
    return system?.name ?? 'NewSystemChoice';
}
/**
 * Gets the semantic key properties from an entity type.
 *
 * @param entityType - The entity type to get semantic keys from
 * @returns Array of semantic key filters
 */
function getSemanticKeyProperties(entityType) {
    const keyNames = [];
    if (entityType?.annotations.Common?.SemanticKey) {
        const semanticKey = entityType.annotations.Common.SemanticKey;
        semanticKey.forEach((keyProperty) => {
            keyNames.push({
                name: keyProperty.value,
                type: keyProperty.$target?.type ?? 'Edm.String',
                value: undefined
            });
        });
    }
    // If no semantic key annotations defined use the key properties
    if (keyNames.length === 0) {
        entityType.keys.forEach((keyProperty) => {
            keyNames.push({
                name: keyProperty.name,
                type: keyProperty.type,
                value: undefined
            });
        });
    }
    return keyNames;
}
/**
 * Find the entity set of the specified type, since mock server needs the files to be named as entity set names.
 *
 * @param entitySets - Array of entity sets to search
 * @param entityTypeFullName - The fully qualified entity type name to find
 * @returns The matching entity set or undefined
 */
function findEntitySet(entitySets, entityTypeFullName) {
    return entitySets.find((entitySet) => entitySet.entityTypeName === entityTypeFullName);
}
/**
 * Gets the navigation property tree which will form the expand queries.
 * Certain property names will be excluded.
 * A limit to the depth can be provided.
 * If the same entity is found or its a leaf, recursion will stop to avoid infinite loops.
 *
 * @param entityType - The entity type to get navigation properties from
 * @param convertedMetadata - The converted metadata object
 * @param ancestorTypes - Keeps track of ancestors to prevent self referential loops and endless nested expansions
 * @param maxDepth - Maximum depth for recursion
 * @returns Array of navigation property entities
 */
function getNavPropsForExpansion(entityType, convertedMetadata, ancestorTypes, maxDepth = 4) {
    const navPropEntities = [];
    if (--maxDepth > 0) {
        entityType.navigationProperties.forEach((entityTypeNavProp) => {
            // Exclude entities that are using specific property names
            if (!types_1.navPropNameExclusions.includes(entityTypeNavProp.name)) {
                let nestedNavPropEntities = [];
                if (entityTypeNavProp.targetType.navigationProperties.length > 0 && maxDepth > 0) {
                    nestedNavPropEntities = getNavPropsForExpansion(entityTypeNavProp.targetType, convertedMetadata, ancestorTypes, maxDepth);
                }
                navPropEntities.push({
                    entityType: entityTypeNavProp.targetType,
                    entityPath: entityTypeNavProp.name,
                    entitySetName: convertedMetadata.entitySets.find((entitySet) => entitySet.entityTypeName === entityTypeNavProp.targetTypeName)?.name ?? 'Unknown',
                    navPropEntities: [...nestedNavPropEntities]
                });
            }
        });
    }
    return navPropEntities;
}
/**
 * Load the entity model for processing to determine the odata queries that are relevant for the application.
 *
 * @param appAccess - Application access reference
 * @param specification - The specification instance
 * @param remoteMetadata - The backend service metadata, as distinct to the local metadata
 * @returns The referenced entities or undefined if not found
 */
async function getEntityModel(appAccess, specification, remoteMetadata) {
    let entities;
    const mainService = appAccess.app.services['mainService'];
    if (mainService.local) {
        const convertedMetadata = (0, annotation_converter_1.convert)((0, edmx_parser_1.parse)(remoteMetadata));
        const appConfig = await specification.readApp({ app: appAccess });
        if (appConfig.applicationModel &&
            appConfig.applicationModel?.target?.fioriElements == src_1.FioriElementsVersion.v4) {
            const appModel = appConfig.applicationModel;
            const pages = appModel.pages;
            let mainListEntityType;
            const pageObjectEntities = [];
            // Get all the app referenced pages and list entity
            Object.values(pages).forEach((page) => {
                // Get the main list entity
                if (page.pageType === src_1.PageTypeV4.ListReport && page.entityType && page.entitySet) {
                    mainListEntityType = convertedMetadata.entityTypes.find((et) => et.fullyQualifiedName === page.entityType);
                    if (mainListEntityType) {
                        const entityKeys = getSemanticKeyProperties(mainListEntityType);
                        entities = {
                            listEntity: {
                                entitySetName: page.entitySet,
                                semanticKeys: entityKeys,
                                entityPath: page.entitySet,
                                entityType: mainListEntityType
                            }
                        };
                        // Add nav props of the list entity
                        entities.listEntity.navPropEntities = getNavPropsForExpansion(mainListEntityType, convertedMetadata);
                    }
                }
                else if (page.pageType === src_1.PageTypeV4.ObjectPage && page.entityType && page.entitySet) {
                    // Dont add the page object for the main entity since it will be the query root entity set
                    if (page.entitySet &&
                        page.entityType &&
                        page.entityType !== mainListEntityType?.fullyQualifiedName) {
                        const objectPageEntitySet = findEntitySet(convertedMetadata.entitySets, page.entityType);
                        const pageEntity = {
                            entityPath: page.navigationProperty,
                            entitySetName: page.entitySet,
                            entityType: objectPageEntitySet?.entityType,
                            page
                        };
                        pageObjectEntities.push(pageEntity);
                    }
                }
            });
            if (!entities?.listEntity) {
                odata_download_generator_1.ODataDownloadGenerator.logger.info((0, i18n_1.t)('info.noListEntityDefined'));
                return undefined;
            }
            entities.pageObjectEntities = pageObjectEntities;
        }
    }
    return entities;
}
//# sourceMappingURL=utils.js.map