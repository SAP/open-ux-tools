"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptState = void 0;
/**
 * Class to manage prompt state including caches for external services and reference facets.
 */
class PromptState {
    // Cache downloaded entity sets since multiple targets within the same service may refer to the same entity set.
    // We only need to download the entity set once. Entity name is unique within the service.
    static externalServiceRequestCache = {};
    // Cache of reference facet paths to prevent re-processing of same metadata repeatedly
    static entityTypeRefFacetCache = {};
    /**
     * Reset the external service request cache.
     *
     * @param extServicePath - Optional specific service path to reset. If not provided, resets entire cache.
     */
    static resetExternalServiceCache(extServicePath) {
        if (extServicePath) {
            delete PromptState.externalServiceRequestCache[extServicePath];
            return;
        }
        PromptState.externalServiceRequestCache = {};
    }
    static resetRefFacetCache() {
        this.entityTypeRefFacetCache = {};
    }
    static resetServiceCaches() {
        PromptState.resetExternalServiceCache();
        PromptState.resetRefFacetCache();
    }
}
exports.PromptState = PromptState;
//# sourceMappingURL=prompt-state.js.map