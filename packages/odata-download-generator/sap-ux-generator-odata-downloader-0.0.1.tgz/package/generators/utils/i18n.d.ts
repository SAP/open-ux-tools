import type { i18n as i18nNext, TOptions } from 'i18next';
export declare const i18n: i18nNext;
export declare const odataDownloadGenerator = "odata-dowload-generator";
/**
 * Initialize i18next with the translations for this module.
 */
export declare function initI18nODataDownloadGenerator(): Promise<void>;
/**
 * Helper function facading the call to i18next. Unless a namespace option is provided the local namespace will be used.
 *
 * @param key i18n key
 * @param options additional options
 * @returns {string} localized string stored for the given key
 */
export declare function t(key: string, options?: TOptions): string;
//# sourceMappingURL=i18n.d.ts.map