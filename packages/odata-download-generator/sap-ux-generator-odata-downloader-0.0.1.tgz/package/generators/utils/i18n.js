"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.odataDownloadGenerator = exports.i18n = void 0;
exports.initI18nODataDownloadGenerator = initI18nODataDownloadGenerator;
exports.t = t;
const i18next_1 = __importDefault(require("i18next"));
const odataDownloadGenerator_i18n_json_1 = __importDefault(require("../translations/odataDownloadGenerator.i18n.json"));
exports.i18n = i18next_1.default.createInstance();
exports.odataDownloadGenerator = 'odata-dowload-generator';
/**
 * Initialize i18next with the translations for this module.
 */
async function initI18nODataDownloadGenerator() {
    await exports.i18n.init({
        resources: {
            en: {
                [exports.odataDownloadGenerator]: odataDownloadGenerator_i18n_json_1.default
            }
        },
        lng: 'en',
        fallbackLng: 'en',
        defaultNS: exports.odataDownloadGenerator,
        ns: [exports.odataDownloadGenerator],
        missingInterpolationHandler: () => '' // Called when interpolation values are undefined, prevents outputting of `{{undefinedProperty}}`
    });
}
/**
 * Helper function facading the call to i18next. Unless a namespace option is provided the local namespace will be used.
 *
 * @param key i18n key
 * @param options additional options
 * @returns {string} localized string stored for the given key
 */
function t(key, options) {
    if (!options?.ns) {
        options = Object.assign(options ?? {}, { ns: exports.odataDownloadGenerator });
    }
    return exports.i18n.t(key, options);
}
initI18nODataDownloadGenerator().catch(() => {
    // Needed for lint
});
//# sourceMappingURL=i18n.js.map